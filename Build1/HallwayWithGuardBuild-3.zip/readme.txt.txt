To play: Open the HallwayWithGuard file.

Notes: This is a playable build that combines art prototypes and gameplay prototypes.
Gameplay components include:
- Working enemy on nav mesh
- Enemy contains multiple states and associated voicelines, like patroling, and chasing
- FPS player movement
- A short range punch on left mouse-click that can affect the enemy and some boxes.
- A working McGuffin. Press E when prompted to clock out. 
- A working "Sanity" (health) meter that increases with pickups

Art components include: 
- Fully textured wall tiles
- Fully textured floor tiles (which also function as ceiling tiles)
- Guard model (customer)
- McGuffin (timecard area)
- Shelves, picnic table, cash register, miscellaneous boxes

Github link: https://github.com/CadenTheKnight/HallwayWithGuard-gp2

Thank you
- Group 1